const { pool } = require("../../config/db.config");
const { SECRET_KEY, PUBLISHABLE_KEY } = require('../../../app/stripe_keys');
const logStripeAction = require("../../maintainLog");
console.log(SECRET_KEY)
const stripe = require('stripe')(SECRET_KEY)
exports.createLog = async (req, res, next) => {
    const client = await pool.connect();
    try {
        const { image, Log_name, description } = req.body;

        if (!Log_name) {
            return res.status(400).json({ error: true, message: "Please Provide Log Name" });
        }

        // Create the Log on Stripe
        const LogData = {
            name: Log_name,
            description: description,
            // Add other Log attributes as needed
        };

        stripe.Logs.create(LogData, async (err, Log) => {
            if (err) {
                logStripeAction('Create Log', [{ name: Log_name, description }], [{ result: Log }], 'error');
                return res.status(500).json({ error: true, message: "Failed to create Log on Stripe" });
            }

            // Insert Log into the database
            const userData = await pool.query("INSERT INTO Logs(image,Log_name,description) VALUES($1,$2,$3) returning *",
                [image || null, Log_name, description || null]
            );

            const data = userData.rows[0];
            logStripeAction('Create Log', [{ name: Log_name, description }], [{ result: Log }], 'success');

            res.status(200).json({
                error: false,
                data: {
                    publishableKey: PUBLISHABLE_KEY,
                    prices: Log,
                },
                message: "Log Created Successfully",
            });
        });
    } catch (err) {
        logStripeAction('Create Log', [{ name: Log_name, description }], [{ result: null }], 'error');
        res.status(500).json({ error: true, data: [], message: "Catch error" });
    } finally {
        client.release();
    }
};
exports.updateLog = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            Log_id,
            image,
            Log_name,
            description

        } = req.body;
        // const company_user = false;
        if (Log_id === null || Log_id === "" || Log_id === undefined) {
            res.json({ error: true, message: "Please Provide Log Id" });

        } else {
            console.log(Log_id)
            const Log = await stripe.Logs.update(
                Log_id,
                {
                    name: Log_name,
                    description: description
                }
            );
            let request_data = [{
                Log_id: Log_id,
                name: Log_name,
                description: description,
            }]
            let response_data = [{
                result: Log,
            }]
            logStripeAction('Upate Log',
                request_data,
                response_data,
                'success'
            )
            let query = 'UPDATE Logs SET ';
            let index = 2;
            let values = [Log_id];

            if (image) {
                query += `image = $${index} , `;
                values.push(image)
                index++
            }
            if (Log_name) {
                query += `Log_name = $${index} , `;
                values.push(Log_name)
                index++
            }
            if (description) {
                query += `description = $${index} , `;
                values.push(description)
                index++
            }
            query += 'WHERE Log_id = $1 RETURNING*'
            query = query.replace(/,\s+WHERE/g, " WHERE");


            const result = await pool.query(query, values)
            res.json({ error: false, data: Log, message: "Log Updated Successfully" });



            // if (result.rows.length === 0) {
            //     res.json({ error: true, data: [], message: "Something went wrong" });

            // } else {
            //     res.json({ error: false, data: result.rows, message: "Log Updated Successfully" });

            // }

        }

    }
    catch (err) {
        let request_data = [{
            Log_id: req.body.Log_id,
            name: req.body.Log_name,
            description: req.body.description,
        }]
        let response_data = [{
            result: null,
        }]
        console.log(err);
        logStripeAction('Update Log',
            request_data,
            response_data,
            'error'
        )
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
    // UPDATE
    // try {
    //     const {Log_id, image, Log_name, description } = req.body;

    //     if (!Log_id) {
    //         return res.status(400).json({ error: true, message: "Please Provide Log Id" });
    //     }

    //     // Create the Log on Stripe
    //     const LogData = {
    //         name: Log_name,
    //         description: description,
    //         // Add other Log attributes as needed
    //     };

    //     stripe.Logs.update(Log_id,LogData, async (err, Log) => {
    //         if (err) {

    //         logStripeAction('Update Log', [{ name: Log_name, description, Log_id:Log_id }], [{ result: Log }], 'error');
    //             return res.status(500).json({ error: true, message: "Failed to update Log on Stripe" });
    //         }

    //         // update 
    //         let query = 'UPDATE Logs SET ';
    //         let index = 2;
    //         let values = [Log_id];

    //         // if (image) {
    //         //     query += `image = $${index} , `;
    //         //     values.push(image)
    //         //     index++
    //         // }
    //         if (Log_name) {
    //             query += `Log_name = $${index} , `;
    //             values.push(Log_name)
    //             index++
    //         }
    //         if (description) {
    //             query += `description = $${index} , `;
    //             values.push(description)
    //             index++
    //         }
    //         query += 'WHERE Log_id = $1 RETURNING*'
    //         query = query.replace(/,\s+WHERE/g, " WHERE");


    //         const result = await pool.query(query, values)
    //         // end 

    //         const data = result.rows[0];
    //         logStripeAction('Update Log', [{ name: Log_name, description, Log_id:Log_id  }], [{ result: Log }], 'success');

    //         res.status(200).json({
    //             error: false,
    //             data: {
    //                 publishableKey: PUBLISHABLE_KEY,
    //                 prices: Log,
    //             },
    //             message: "Log Update Successfully",
    //         });
    //     });
    // } catch (err) {
    //     logStripeAction('Update Log', [{ name: Log_name, description , Log_id:Log_id }], [{ result: null }], 'error');
    //     res.status(500).json({ error: true, data: [], message: "Catch error" });
    // } finally {
    //     client.release();
    // }

}
exports.archieveLog = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            Log_id,
            active

        } = req.body;
        // const company_user = false;
        if (Log_id === null || Log_id === "" || Log_id === undefined) {
            res.json({ error: true, message: "Please Provide Log Id" });

        } else {
            const Log = await stripe.Logs.update(
                Log_id,
                {
                    active: active,
                }
            );
            let request_data = [{
                Log_id: Log_id,
                active: active
            }]
            let response_data = [{
                result: Log,
            }]
            logStripeAction('Upate Log',
                request_data,
                response_data,
                'success'
            )
            res.json({ error: false, data: Log, message: "Log Updated Successfully" });

            // let query = 'UPDATE Logs SET ';
            // let index = 2;
            // let values = [Log_id];

            // if (image) {
            //     query += `image = $${index} , `;
            //     values.push(image)
            //     index++
            // }
            // if (Log_name) {
            //     query += `Log_name = $${index} , `;
            //     values.push(Log_name)
            //     index++
            // }
            // if (description) {
            //     query += `description = $${index} , `;
            //     values.push(description)
            //     index++
            // }
            // query += 'WHERE Log_id = $1 RETURNING*'
            // query = query.replace(/,\s+WHERE/g, " WHERE");


            // const result = await pool.query(query, values)

            // if (result.rows.length === 0) {
            //     res.json({ error: true, data: [], message: "Something went wrong" });

            // } else {
            //     res.json({ error: false, data: result.rows, message: "Log Updated Successfully" });

            // }

        }

    }
    catch (err) {
        let request_data = [{
            Log_id: Log_id,
            active: active,
        }]
        let response_data = [{
            result: null,
        }]
        console.log(err);
        logStripeAction('Update Log',
            request_data,
            response_data,
            'error'
        )
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
}
exports.deleteLog = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            Log_id,
        } = req.body;
        // const company_user = false;
        if (Log_id === null || Log_id === "" || Log_id === undefined) {
            let request_data = [{
                Log_id: Log_id,
            }]
            let response_data = [{
                result: null,
            }]
            console.log(err);
            logStripeAction('Delete Log',
                request_data,
                response_data,
                'error'
            )
            res.json({ error: true, message: "Please Provide Log Id" });

        } else {
            const deleted = await stripe.Logs.del(
                Log_id
            );
            let request_data = [{
                Log_id: Log_id,
            }]
            let response_data = [{
                result: deleted,
            }]
            logStripeAction('Delete Log',
                request_data,
                response_data,
                'success'
            )
            res.json({ error: false, data: deleted, message: "Log Deleted Successfully" });

            // const deleteUserQuery = await pool.query(
            //     "DELETE FROM Logs WHERE Log_id = $1",
            //     [Log_id]
            // );

            // // Check if any rows were deleted
            // if (deleteUserQuery.rowCount === 1) {
            //     res.json({ error: false, message: "Log Deleted Successfully" });
            // } else {
            //     res.json({ error: true, message: "Cannot Delete Log" });
            // }

        }

    }
    catch (err) {
        let request_data = [{
            Log_id: Log_id,
        }]
        let response_data = [{
            result: null,
        }]
        console.log(err);
        logStripeAction('Delete Log',
            request_data,
            response_data,
            'error'
        )
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
}
exports.deleteAllLog = async (req, res) => {
    const client = await pool.connect();
    try {

        const deleteUserQuery = await pool.query(
            "DELETE FROM Logs"
        );

        // Check if any rows were deleted
        if (deleteUserQuery.rowCount === 0) {
            res.json({ error: true, message: "Cannot Delete Log" });

        } else {
            res.json({ error: false, message: "All Log Deleted Successfully" });

        }

    }
    catch (err) {
        res.json({ error: true, data: [], message: "Catch eror" });

    } finally {
        client.release();
    }
}

exports.getAllLogs = async (req, res) => {
    const client = await pool.connect();
    try {
        // const Logs = await stripe.Logs.list();
        // res.json({
        //     message: "All Logs Fetched",
        //     error: false,
        //     result: Logs
        // })
        const query = 'SELECT * FROM stripe_logs'
        const result = await pool.query(query);


        if (result.rows) {
            res.json({
                message: "All Logs Fetched",
                error: false,
                result: result.rows
            })
        }
        else {
            res.json({
                message: "could not fetch",
                error: true,
            })
        }
    }
    catch (err) {
        console.log(err)
        res.json({
            message: "Error Occurred",
            error: true,
        })
    }
    finally {
        client.release();
    }
}

exports.getLogDetails = async (req, res) => {
    const client = await pool.connect();
    try {
        const {
            log_id,
        } = req.body;
        //    const type="admin"
        const query = 'SELECT * FROM stripe_logs WHERE log_id =$1 '
        const result = await pool.query(query, [log_id]);
        // get messages 
        const Data = result.rows[0]//Log
        res.json({
            message: "All Logs Fetched",
            error: false,
            data: Data,
        });

    }
    catch (err) {
        console.log(err)
        res.json({
            message: "Error Occurred",
            error: true,
            data: err.message
        })
    }
    finally {
        client.release();
    }
}


